
 ### v2.0.0 - 2018-08-06 
 **Changes:** 
 * Added Template Feature
* Added Instant Refresh for Controls
* Fixed issue with Security plugins and Multisite
 
 ### v1.2.1 - 2018-01-05 
 **Changes:** 
 * Improves compatiblity with latest WordPress version.
* Sync ThemeIsle SDK.
 
 ### v1.2.0 - 2017-10-16 
 **Changes:** 
 * Adds tested up to wp 4.8.
* Improvements to dashboard widget, rollback.
 
### 1.1.0 - 19/01/2017
**Changes:** 
- Added dashboard widget

### 1.0.8 - 27/10/2016
**Changes:** 
- Removed notification script

### 1.0.7 - 30/05/2016
**Changes:** 
- Improved customizer settings
- Removed security addon mentions in the free version


### 1.0.6 - 11/01/2016

 Changes: 


 * added subscribe form


### 1.0.4 - 11/01/2016

 Changes: 


 * * added notification for security addon
 * Improved code format
 * Merge pull request #7 from cristian-ungureanu/development

Development


### 1.0.2 - 23/06/2015

 Changes: 


 * Remove phpstorm files
 * Remove phpstorm files
 * Merge branch 'development' of https://github.com/Codeinwp/login-customizer into development


### 1.0.2 - 23/06/2015

 Changes: 


 * * added support for pro version
