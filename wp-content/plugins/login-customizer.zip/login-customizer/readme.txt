=== Custom Login Page Customizer ===
Stable tag: trunk
Requires at least: 4.0
Tested up to: 5.2
Contributors: hardeepasrani,marius_codeinwp
Author URI: https://themeisle.com
Tags: login, customizer, logo, login logo, login customizer, login page,admin, branding, customization, custom login, error, login error, custom login pro
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom Login Customizer allows you to easily customize your admin login page, straight from your WordPress Customizer!

== Description ==

<a href="https://themeisle.com/plugins/login-customizer/" target="_blank" rel="nofollow">Custom Login Page Customizer</a> plugin allows you to easily customize your login page straight from your WordPress Customizer! You can preview your custom login changes before you save them! Awesome, right?

https://www.youtube.com/watch?v=rtXJ44BsSWM

In your WordPress Dashboard, navigate to Appearance > Custom Login Page Customizer to get started.

You can customize almost anything and make it look the way you want.

If you are looking for the best WordPress themes that works with Login Customizer check this out : <a href="http://www.codeinwp.com/blog/best-free-wordpress-themes/" target="_blank" rel="nofollow">http://www.codeinwp.com/blog/best-free-wordpress-themes/</a>
== Installation ==

1. Upload the plugin to your 'wp-content/plugins' directory, or download and install automatically through your admin panel.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= How to customizer? =

In your WordPress Dashboard, navigate to Appearance > Custom Login Customizer to get started.

= How to donate or contribute? =

Please visit <a target="_blank" rel="nofollow" href="http://themeisle.com">this link</a> for more info.

== Screenshots ==

1. Example Custom Login Page
2. Another Great Custom Login Page Example

== Changelog ==
= 2.0.0 - 2018-08-06  =

* Added Template Feature
* Added Instant Refresh for Controls
* Fixed issue with Security plugins and Multisite


= 2.0 - 2018-03-09  =

* Fixed issues with security plugins
* Added Instant Refresh
* Improved UX
* Added more controls


= 1.2.1 - 2018-01-05  =

* Improves compatiblity with latest WordPress version.
* Sync ThemeIsle SDK.


= 1.2.0 - 2017-10-16  =

* Adds tested up to wp 4.8.
* Improvements to dashboard widget, rollback.



**New in v1.0.8**

* Removed notifications

**New in v1.0.7**

* Improved customizer settings
* Removed security addon mentions in the free version
